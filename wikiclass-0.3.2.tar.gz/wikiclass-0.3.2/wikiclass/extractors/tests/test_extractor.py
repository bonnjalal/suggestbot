import mwparserfromhell as mwp
from nose.tools import eq_

from ..extractor import Extractor, TemplateExtractor
